Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement



Public Class LoginForm1
    Public q As String

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See https://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MsgBox("Fields are required")
            Edit()


            Exit Sub
        End If

        Query("Select * from UserLogin WHERE UserName = '" & txtUsername.Text & "' and Password = '" & txtPassword.Text & "'")
        If ds1.Tables("querytable").Rows.Count = 0 Then
            MsgBox("Please check username and password")

            'txtUsername.Clear()
            'txtPassword.Clear()


            Exit Sub
        Else
            If ds1.Tables("querytable").Rows(0)(5) = "Admin" Then
                MsgBox("Success")
                Dboard.ToolStripStatusLabel1.Text = "Admin"
                Dboard.Show()
                'Me.Close()
                Edit()


            ElseIf ds1.Tables("querytable").Rows(0)(5) = "Staff" Then
                MsgBox("Success")
                Dboard.ToolStripStatusLabel1.Text = "Staff"
                Dboard.Show()
                'Me.Close()
                Edit()


            End If

        End If
    End Sub

    Public Sub Edit()
        q = "insert into UserLoginAudit values('" & My.Forms.LoginForm1.txtUsername.Text & "','" & My.Forms.LoginForm1.txtPassword.Text & "','" & My.Forms.Dboard.ToolStripStatusLabel1.Text & "',' OUT  ',' " & DateTime.Now & "')"
        Dim cmd As New SqlCommand("INSERT INTO UserLoginAudit VALUES(@txt1, @txt2, @txt3, 'IN',  @date1)")
        cmd.Parameters.AddWithValue("@txt1", My.Forms.LoginForm1.txtUsername.Text)
        cmd.Parameters.AddWithValue("@txt2", My.Forms.LoginForm1.txtPassword.Text)
        cmd.Parameters.AddWithValue("@txt3", My.Forms.Dboard.ToolStripStatusLabel1.Text)
        cmd.Parameters.Add("@date1", SqlDbType.DateTime).Value = DateTime.Now
        If (InsertData(cmd)) Then

            'Application.Exit()
        End If

    End Sub




    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenConnection()
    End Sub
End Class
