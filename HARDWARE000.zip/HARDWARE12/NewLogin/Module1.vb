﻿Imports System.Data.SqlClient
Module Module1

    Public con1 As New SqlConnection("Data Source=DESKTOP-1BDIBI4\SQLEXPRESS;Initial Catalog=WrcayDB1;Integrated Security=True")
    '("Data Source=DESKTOP-NOP9SR5\SQLEXPRESS;Initial Catalog=WrcayDB;Integrated Security=True")
    Public cmd1 As New SqlCommand
    Public da1 As New SqlDataAdapter
    Public ds1 As New DataSet
    Public dt1 As New DataTable
    Public qr1 As String
    Public i1 As Integer
    Public Function OpenConnection()
        If con1.State = ConnectionState.Closed Then
            con1.Open()
        End If
        Return True

    End Function


    Public Function Query(statement As String)
        Try
            da1 = New SqlDataAdapter(statement, con1)
            ds1 = New DataSet
            da1.Fill(ds1, "querytable")

        Catch ex As Exception

        End Try

        Return False

    End Function

    Public Function Command(statement As String)
        Try

            cmd1 = New SqlCommand(statement, con1)
            cmd1.ExecuteNonQuery()
        Catch ex As Exception

        End Try
        Return False

    End Function
End Module
