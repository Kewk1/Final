﻿Imports System.Data.SqlClient



Public Class Dboard

    Public q As String

    Private Sub Dboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoggedUser.Text = My.Forms.Loginform.LoginUser

        ' BindGd()
        'Usrtyp()


    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        EditUser()
        My.Forms.Loginform.TxtBox1.Clear()
        My.Forms.Loginform.TxtBox2.Clear()

    End Sub
    Sub childform(ByVal panel As Form)
        Panel1.Controls.Clear()
        panel.TopLevel = False
        panel.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        panel.Dock = DockStyle.Fill
        Panel1.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub EditUser()

        q = "insert into UserLoginAudit values('" & My.Forms.LoginForm1.txtUsername.Text & "','" & My.Forms.LoginForm1.txtPassword.Text & "','" & My.Forms.Dboard.ToolStripStatusLabel1.Text & "',' OUT ',' " & DateTime.Now & "')"
        Dim cmd As New SqlCommand("INSERT INTO UserLoginAudit VALUES(@txt1, @txt2, @txt3, 'OUT',  @date1)")
        cmd.Parameters.AddWithValue("@txt1", My.Forms.LoginForm1.txtUsername.Text)
        cmd.Parameters.AddWithValue("@txt2", My.Forms.LoginForm1.txtPassword.Text)
        cmd.Parameters.AddWithValue("@txt3", My.Forms.Dboard.ToolStripStatusLabel1.Text)
        cmd.Parameters.Add("@date1", SqlDbType.DateTime).Value = DateTime.Now
        If (InsertData(cmd)) Then

            Application.Exit()
        End If


    End Sub

    Private Sub btnPOS_Click(sender As Object, e As EventArgs) Handles btnPOS.Click
        childform(SellItem)
    End Sub

    Private Sub btnacc_Click(sender As Object, e As EventArgs) Handles btnacc.Click

        If ToolStripStatusLabel1.Text = "Staff" Then
            MsgBox("Only admin can access")
            Exit Sub
        End If
        childform(RegistrationForm)
    End Sub

    Private Sub btncu_Click(sender As Object, e As EventArgs) Handles btncu.Click
        LoginForm1.Show()
        My.Forms.LoginForm1.txtUsername.Clear()
        My.Forms.LoginForm1.txtPassword.Clear()
        Me.Close()

    End Sub

    Private Sub btnsales_Click(sender As Object, e As EventArgs) Handles btnsales.Click
        If ToolStripStatusLabel1.Text = "Staff" Then
            MsgBox("Only admin can access")
            Exit Sub
        End If

        childform(Salesfrm)
    End Sub

    Private Sub btnsupp_Click(sender As Object, e As EventArgs) Handles btnsupp.Click
        childform(StockItem)
    End Sub

    Private Sub btnLM_Click(sender As Object, e As EventArgs) Handles btnLM.Click
        If ToolStripStatusLabel1.Text = "Staff" Then
            MsgBox("Only admin can access")
            Exit Sub
        End If
        childform(Loghist)
    End Sub

    Private Sub btnInventory_Click(sender As Object, e As EventArgs) Handles btnInventory.Click
        childform(Maintenance)
    End Sub

    Private Sub btnprod_Click(sender As Object, e As EventArgs) Handles btnprod.Click
        childform(Item1)
    End Sub

    Private Sub Dboard_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim msg As String = "Are you sure you want to Closed the form?"
        Dim title As String = "Form Closing"
        Dim result = MessageBox.Show(msg, title, MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If result = DialogResult.Cancel Then
            e.Cancel = True
        End If

    End Sub

    Private Sub Stockbtn_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub LoggedUser_Click(sender As Object, e As EventArgs) Handles LoggedUser.Click

    End Sub






    ' Public Sub Usrtyp()
    'qr = "select * from UserLogin where UserType = '" & My.Forms.Loginform.Cmbox.SelectedItem.text & "'" Then
    'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
    '    If (logincorrect) Then

    ' TextBox2.Text = "admin"
    '  Else
    '  TextBox2.Text = "staff"
    '
    '  End If

    '  End If
    ' End Sub


End Class