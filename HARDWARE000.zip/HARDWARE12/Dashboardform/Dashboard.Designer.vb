﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dboard))
        Me.LoggedUser = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnprod = New System.Windows.Forms.Button()
        Me.btnInventory = New System.Windows.Forms.Button()
        Me.btnLM = New System.Windows.Forms.Button()
        Me.btnsupp = New System.Windows.Forms.Button()
        Me.btnsales = New System.Windows.Forms.Button()
        Me.btncu = New System.Windows.Forms.Button()
        Me.btnacc = New System.Windows.Forms.Button()
        Me.btnPOS = New System.Windows.Forms.Button()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LoggedUser
        '
        Me.LoggedUser.AutoSize = True
        Me.LoggedUser.Location = New System.Drawing.Point(1063, 73)
        Me.LoggedUser.Name = "LoggedUser"
        Me.LoggedUser.Size = New System.Drawing.Size(10, 13)
        Me.LoggedUser.TabIndex = 5
        Me.LoggedUser.Text = "."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.RosyBrown
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(449, 73)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(452, 37)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "WRcay HARDWARE STORE"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.BackColor = System.Drawing.Color.RosyBrown
        Me.LinkLabel1.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(32, 571)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(67, 30)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "LogOut"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.RosyBrown
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(17, 114)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(239, 40)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "DASHBOARD"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.RosyBrown
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(173, 25)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(49, 20)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Staff"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.RosyBrown
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(158, 45)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(66, 20)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "ADMIN"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.RosyBrown
        Me.Panel1.Location = New System.Drawing.Point(287, 114)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(806, 487)
        Me.Panel1.TabIndex = 41
        '
        'btnprod
        '
        Me.btnprod.BackgroundImage = CType(resources.GetObject("btnprod.BackgroundImage"), System.Drawing.Image)
        Me.btnprod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnprod.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprod.Location = New System.Drawing.Point(24, 487)
        Me.btnprod.Name = "btnprod"
        Me.btnprod.Size = New System.Drawing.Size(145, 60)
        Me.btnprod.TabIndex = 40
        Me.btnprod.Text = "               Products"
        Me.btnprod.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnprod.UseVisualStyleBackColor = True
        '
        'btnInventory
        '
        Me.btnInventory.BackgroundImage = CType(resources.GetObject("btnInventory.BackgroundImage"), System.Drawing.Image)
        Me.btnInventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnInventory.Font = New System.Drawing.Font("Impact", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInventory.Location = New System.Drawing.Point(24, 421)
        Me.btnInventory.Name = "btnInventory"
        Me.btnInventory.Size = New System.Drawing.Size(145, 60)
        Me.btnInventory.TabIndex = 39
        Me.btnInventory.Text = "               Inventory"
        Me.btnInventory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnInventory.UseVisualStyleBackColor = True
        '
        'btnLM
        '
        Me.btnLM.BackgroundImage = CType(resources.GetObject("btnLM.BackgroundImage"), System.Drawing.Image)
        Me.btnLM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnLM.Font = New System.Drawing.Font("Impact", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLM.Location = New System.Drawing.Point(958, 5)
        Me.btnLM.Name = "btnLM"
        Me.btnLM.Size = New System.Drawing.Size(145, 60)
        Me.btnLM.TabIndex = 38
        Me.btnLM.Text = "               Log                           Manager"
        Me.btnLM.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnLM.UseVisualStyleBackColor = True
        '
        'btnsupp
        '
        Me.btnsupp.BackgroundImage = CType(resources.GetObject("btnsupp.BackgroundImage"), System.Drawing.Image)
        Me.btnsupp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnsupp.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsupp.Location = New System.Drawing.Point(24, 355)
        Me.btnsupp.Name = "btnsupp"
        Me.btnsupp.Size = New System.Drawing.Size(145, 60)
        Me.btnsupp.TabIndex = 37
        Me.btnsupp.Text = "               Supplier"
        Me.btnsupp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsupp.UseVisualStyleBackColor = True
        '
        'btnsales
        '
        Me.btnsales.BackgroundImage = CType(resources.GetObject("btnsales.BackgroundImage"), System.Drawing.Image)
        Me.btnsales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnsales.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsales.Location = New System.Drawing.Point(24, 289)
        Me.btnsales.Name = "btnsales"
        Me.btnsales.Size = New System.Drawing.Size(145, 60)
        Me.btnsales.TabIndex = 36
        Me.btnsales.Text = "           Sales"
        Me.btnsales.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnsales.UseVisualStyleBackColor = True
        '
        'btncu
        '
        Me.btncu.BackgroundImage = CType(resources.GetObject("btncu.BackgroundImage"), System.Drawing.Image)
        Me.btncu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btncu.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncu.Location = New System.Drawing.Point(807, 5)
        Me.btncu.Name = "btncu"
        Me.btncu.Size = New System.Drawing.Size(145, 60)
        Me.btncu.TabIndex = 35
        Me.btncu.Text = "                        Change           User"
        Me.btncu.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btncu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btncu.UseVisualStyleBackColor = True
        '
        'btnacc
        '
        Me.btnacc.BackgroundImage = CType(resources.GetObject("btnacc.BackgroundImage"), System.Drawing.Image)
        Me.btnacc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnacc.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnacc.Location = New System.Drawing.Point(24, 223)
        Me.btnacc.Name = "btnacc"
        Me.btnacc.Size = New System.Drawing.Size(145, 60)
        Me.btnacc.TabIndex = 34
        Me.btnacc.Text = "             Accounts"
        Me.btnacc.UseVisualStyleBackColor = True
        '
        'btnPOS
        '
        Me.btnPOS.BackgroundImage = CType(resources.GetObject("btnPOS.BackgroundImage"), System.Drawing.Image)
        Me.btnPOS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnPOS.Font = New System.Drawing.Font("Impact", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPOS.Location = New System.Drawing.Point(24, 157)
        Me.btnPOS.Name = "btnPOS"
        Me.btnPOS.Size = New System.Drawing.Size(145, 60)
        Me.btnPOS.TabIndex = 33
        Me.btnPOS.Text = "         POS"
        Me.btnPOS.UseVisualStyleBackColor = True
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.RosyBrown
        Me.PictureBox9.Image = Global.HARDWARE12.My.Resources.Resources.Admin_icon
        Me.PictureBox9.Location = New System.Drawing.Point(14, 1)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(131, 101)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 29
        Me.PictureBox9.TabStop = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 588)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1097, 22)
        Me.StatusStrip1.TabIndex = 42
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(119, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'Dboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RosyBrown
        Me.ClientSize = New System.Drawing.Size(1097, 610)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnprod)
        Me.Controls.Add(Me.btnInventory)
        Me.Controls.Add(Me.btnLM)
        Me.Controls.Add(Me.btnsupp)
        Me.Controls.Add(Me.btnsales)
        Me.Controls.Add(Me.btncu)
        Me.Controls.Add(Me.btnacc)
        Me.Controls.Add(Me.btnPOS)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.LoggedUser)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Dboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LoggedUser As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnPOS As Button
    Friend WithEvents btnacc As Button
    Friend WithEvents btncu As Button
    Friend WithEvents btnsales As Button
    Friend WithEvents btnsupp As Button
    Friend WithEvents btnLM As Button
    Friend WithEvents btnInventory As Button
    Friend WithEvents btnprod As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
End Class
