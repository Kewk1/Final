﻿Imports System.Data.SqlClient

Public Class PendingSell
    Private Sub PendingSell_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Pendin()

    End Sub
    Public Sub Pendin()
        qr = "Select * from PendingSell"
        'qr = "Select * from tblProductInfo"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)

        Else
            MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub
    Public Sub Del()
        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then


            'qr = "Delete from SpProd where ProductID= '" & Convert.ToInt32(TextBox1.Text) & "'"
            Dim cmd As New SqlCommand("DELETE FROM PendingSell WHERE ProdSaleID = @id")
            cmd.Parameters.AddWithValue("@id", TextBox1.Text)
            'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                ' BindGD()

                Pendin()



                ' MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


            Else
                ' MsgBox("error record not saved", MsgBoxStyle.Critical)
            End If

        End If

    End Sub
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            Me.TextBox1.Text = DataGridView1.Item(0, i).Value
            Me.TextBox2.Text = DataGridView1.Item(1, i).Value
            Me.TextBox3.Text = DataGridView1.Item(2, i).Value
            Me.TextBox4.Text = DataGridView1.Item(3, i).Value
            Me.TextBox5.Text = DataGridView1.Item(4, i).Value
            Me.TextBox6.Text = DataGridView1.Item(5, i).Value
            Me.TextBox7.Text = DataGridView1.Item(6, i).Value
            Me.TextBox8.Text = DataGridView1.Item(7, i).Value
            Me.TextBox8.Text = DataGridView1.Item(8, i).Value
        End If


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        If (Isformvalid()) Then
            qr = "insert into ProSale values('" & Convert.ToInt32(TextBox1.Text) & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & DateTime.Now & "','" & My.Forms.Dboard.ToolStripStatusLabel1.Text & "')"
            Dim cmd As New SqlCommand("INSERT INTO ProSale VALUES(@txt1, @txt2, @txt3, @txt4,@txt5,@txt6,@txt7,@txt8)")
            cmd.Parameters.AddWithValue("@txt1", TextBox1.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox2.Text)
            cmd.Parameters.AddWithValue("@txt3", TextBox3.Text)
            cmd.Parameters.AddWithValue("@txt4", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt5", TextBox5.Text)
            cmd.Parameters.AddWithValue("@txt6", TextBox6.Text)
            cmd.Parameters.AddWithValue("@txt7", SqlDbType.Date).Value = DateTime.Now
            cmd.Parameters.AddWithValue("@txt8", My.Forms.Dboard.ToolStripStatusLabel1.Text)
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            If InsertData(cmd) Then


                ' EditAudit()
                Del()


                ' MsgBox("sold", MsgBoxStyle.Information)
            Else

                MsgBox("Error record Not saved", MsgBoxStyle.Critical)

            End If



        End If
    End Sub
    Private Function Isformvalid() As Boolean
        If (TextBox4.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False

        End If

        If (TextBox3.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If

        If (TextBox5.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()


            Return False
        End If
        Return True

    End Function
End Class