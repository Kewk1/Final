﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Loghist
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        i = DataGridView1.CurrentRow.Index
        If (1 > 0) Then
            My.Forms.Loginform.Txtbox1.Text = DataGridView1.Item(0, i).Value
            My.Forms.Loginform.Txtbox2.Text = DataGridView1.Item(1, i).Value


        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.MultiSelect = True
        BindGD()


    End Sub



    Public Sub BindGD()
        qr = "select * from UserLoginAudit"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            MsgBox("Record not found", MsgBoxStyle.Critical)

        End If
    End Sub





    Public Sub SupplHstr()
        qr = "select * from SpProd"
        ds = Searchdata(qr)

        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("record Not found", MsgBoxStyle.Critical)

        End If
    End Sub



    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        LoghisUser()

    End Sub
    Public Sub LoghisUser()
        qr = "Select * from UserLogin"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)

        Else
            'MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        qr = "Select * from Prosale"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)

        Else
            'MsgBox("Record Not Found", MsgBoxStyle.Critical)

        End If
    End Sub


    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click


        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then

            If (Isformvalid2()) Then
                'qr = "Delete from UserLoginAudit where AuditID= '" & Convert.ToInt32(My.Forms.Loginform.Txtbox1.Text) & "'"
                Dim cmd As New SqlCommand("DELETE FROM UserLoginAudit WHERE AuditID = @id")
                cmd.Parameters.AddWithValue("@id", My.Forms.Loginform.Txtbox1.Text)
                'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
                If (InsertData(cmd)) Then
                    'BindGD()

                    MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


                Else
                    MsgBox("error record not saved", MsgBoxStyle.Critical)

                End If
            End If
        End If
    End Sub

    Private Function Isformvalid2() As Boolean
        If (My.Forms.Loginform.Txtbox1.Text.Trim() = String.Empty) Then
            MsgBox("Product ID is required", MsgBoxStyle.Critical)


            Return False


        End If
        Return True

    End Function

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        SupplHstr()

    End Sub
End Class