﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class StockItem
    Public q As String


    Private Function Isformvalid() As Boolean
        If (TextBox4.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()


            Return False

        End If

        If (TextBox3.Text.Trim() = String.Empty) Then
            'MsgBox("Username Is required", MsgBoxStyle.Critical)
            TextBox4.Clear()
            TextBox2.Clear()
            TextBox3.Clear()



            Return False
        End If


        Return True
    End Function
    Public Sub BindGd()

        qr = "select * from supp"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("Record not found..", MsgBoxStyle.Critical)
        End If

    End Sub

    Private Sub AddSupp_Click(sender As Object, e As EventArgs) Handles AddSupp.Click
        If (Isformvalid()) Then
            qr = "insert into Supp values('" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & DateTime.Now & "')"
            Dim cmd As New SqlCommand("INSERT INTO Supp VALUES(@txt1, @txt2, @txt3, @txt4, @date1)")
            cmd.Parameters.AddWithValue("@txt1", TextBox2.Text)
            cmd.Parameters.AddWithValue("@txt2", TextBox3.Text)
            cmd.Parameters.AddWithValue("@txt3", TextBox4.Text)
            cmd.Parameters.AddWithValue("@txt4", TextBox5.Text)
            cmd.Parameters.Add("@date1", SqlDbType.Date).Value = DateTime.Now
            'Dim logincorrect As Boolean = Convert.ToBoolean(InsertData(qr))
            If (InsertData(cmd)) Then
                BindGd()


                MsgBox("Added", MsgBoxStyle.Information)
            Else
                MsgBox("S", MsgBoxStyle.Critical)
            End If
        End If
    End Sub

    Private Sub StockItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindGd()

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        i = DataGridView1.CurrentRow.Index
        If 1 > 0 Then
            Me.TextBox1.Text = DataGridView1.Item(0, i).Value
            Me.TextBox2.Text = DataGridView1.Item(1, i).Value
            Me.TextBox3.Text = DataGridView1.Item(2, i).Value
            Me.TextBox4.Text = DataGridView1.Item(3, i).Value
            Me.TextBox5.Text = DataGridView1.Item(4, i).Value

        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim result As Integer = MsgBox("Do you really want to delete record..?", MsgBoxStyle.YesNo)
        If result = DialogResult.No Then
        ElseIf result = DialogResult.Yes Then

            If (Isformvalid2()) Then
                'qr = "Delete from supp where ID= '" & Convert.ToInt32(My.Forms.StockItem.TextBox1.Text) & "'"
                Dim cmd As New SqlCommand("DELETE FROM supp WHERE ID = @id")
                cmd.Parameters.AddWithValue("@id", My.Forms.StockItem.TextBox1.Text)
                'Dim Wantodelete As Boolean = Convert.ToBoolean(InsertData(qr))
                If (InsertData(cmd)) Then
                    BindGd()

                    MsgBox("Stock Update succesfully", MsgBoxStyle.Information)


                Else
                    MsgBox("error record not saved", MsgBoxStyle.Critical)

                End If
            End If
        End If
    End Sub
    Private Function Isformvalid2() As Boolean
        If (TextBox1.Text.Trim() = String.Empty) Then
            MsgBox("Product ID is required", MsgBoxStyle.Critical)


            Return False


        End If
        Return True

    End Function

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        AddSupProd.Show()

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        SupProd.Show()

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class