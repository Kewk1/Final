﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Maintenance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1S = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Addbtn = New System.Windows.Forms.Button()
        Me.Updtbtn = New System.Windows.Forms.Button()
        Me.Dltbtn = New System.Windows.Forms.Button()
        Me.Cancelbtn = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Prodidbox = New System.Windows.Forms.TextBox()
        Me.Txtbox2 = New System.Windows.Forms.TextBox()
        Me.Txtbox3 = New System.Windows.Forms.TextBox()
        Me.txtbox4 = New System.Windows.Forms.TextBox()
        Me.txtbox5 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(417, 97)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(58, 20)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1S
        '
        Me.TextBox1S.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1S.Location = New System.Drawing.Point(226, 92)
        Me.TextBox1S.Name = "TextBox1S"
        Me.TextBox1S.Size = New System.Drawing.Size(185, 29)
        Me.TextBox1S.TabIndex = 13
        Me.TextBox1S.Text = "Search ID"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(226, 127)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(552, 316)
        Me.DataGridView1.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(11, 35)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(54, 27)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "new"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Addbtn
        '
        Me.Addbtn.Location = New System.Drawing.Point(48, 349)
        Me.Addbtn.Name = "Addbtn"
        Me.Addbtn.Size = New System.Drawing.Size(55, 47)
        Me.Addbtn.TabIndex = 15
        Me.Addbtn.Text = "Add"
        Me.Addbtn.UseVisualStyleBackColor = True
        '
        'Updtbtn
        '
        Me.Updtbtn.Location = New System.Drawing.Point(109, 349)
        Me.Updtbtn.Name = "Updtbtn"
        Me.Updtbtn.Size = New System.Drawing.Size(51, 47)
        Me.Updtbtn.TabIndex = 16
        Me.Updtbtn.Text = "Update"
        Me.Updtbtn.UseVisualStyleBackColor = True
        '
        'Dltbtn
        '
        Me.Dltbtn.Location = New System.Drawing.Point(48, 402)
        Me.Dltbtn.Name = "Dltbtn"
        Me.Dltbtn.Size = New System.Drawing.Size(51, 47)
        Me.Dltbtn.TabIndex = 17
        Me.Dltbtn.Text = "Delete"
        Me.Dltbtn.UseVisualStyleBackColor = True
        '
        'Cancelbtn
        '
        Me.Cancelbtn.Location = New System.Drawing.Point(105, 402)
        Me.Cancelbtn.Name = "Cancelbtn"
        Me.Cancelbtn.Size = New System.Drawing.Size(55, 47)
        Me.Cancelbtn.TabIndex = 18
        Me.Cancelbtn.Text = "cancel"
        Me.Cancelbtn.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(481, 98)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(61, 19)
        Me.Button3.TabIndex = 19
        Me.Button3.Text = "Clear"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel1.Location = New System.Drawing.Point(8, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(49, 13)
        Me.LinkLabel1.TabIndex = 20
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Category"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.LinkLabel2.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel2.Location = New System.Drawing.Point(63, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(28, 13)
        Me.LinkLabel2.TabIndex = 21
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "VAT"
        '
        'Prodidbox
        '
        Me.Prodidbox.Enabled = False
        Me.Prodidbox.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Prodidbox.Location = New System.Drawing.Point(49, 107)
        Me.Prodidbox.Name = "Prodidbox"
        Me.Prodidbox.Size = New System.Drawing.Size(139, 27)
        Me.Prodidbox.TabIndex = 5
        Me.Prodidbox.Text = "Product ID"
        '
        'Txtbox2
        '
        Me.Txtbox2.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtbox2.Location = New System.Drawing.Point(48, 140)
        Me.Txtbox2.Name = "Txtbox2"
        Me.Txtbox2.Size = New System.Drawing.Size(140, 27)
        Me.Txtbox2.TabIndex = 6
        Me.Txtbox2.Text = "Product name"
        '
        'Txtbox3
        '
        Me.Txtbox3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtbox3.Location = New System.Drawing.Point(50, 173)
        Me.Txtbox3.Name = "Txtbox3"
        Me.Txtbox3.Size = New System.Drawing.Size(138, 27)
        Me.Txtbox3.TabIndex = 7
        Me.Txtbox3.Text = "Product Description"
        '
        'txtbox4
        '
        Me.txtbox4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbox4.Location = New System.Drawing.Point(49, 206)
        Me.txtbox4.Name = "txtbox4"
        Me.txtbox4.Size = New System.Drawing.Size(138, 27)
        Me.txtbox4.TabIndex = 8
        Me.txtbox4.Text = "Price"
        '
        'txtbox5
        '
        Me.txtbox5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbox5.Location = New System.Drawing.Point(50, 239)
        Me.txtbox5.Name = "txtbox5"
        Me.txtbox5.Size = New System.Drawing.Size(138, 27)
        Me.txtbox5.TabIndex = 9
        Me.txtbox5.Text = "Stock Qty."
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(48, 272)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(138, 27)
        Me.TextBox1.TabIndex = 12
        Me.TextBox1.Text = "Supplier Name"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(48, 305)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(140, 28)
        Me.ComboBox1.TabIndex = 13
        Me.ComboBox1.Text = "Category"
        '
        'Maintenance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RosyBrown
        Me.ClientSize = New System.Drawing.Size(806, 487)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Cancelbtn)
        Me.Controls.Add(Me.txtbox5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Dltbtn)
        Me.Controls.Add(Me.txtbox4)
        Me.Controls.Add(Me.Addbtn)
        Me.Controls.Add(Me.Updtbtn)
        Me.Controls.Add(Me.Txtbox3)
        Me.Controls.Add(Me.Txtbox2)
        Me.Controls.Add(Me.TextBox1S)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Prodidbox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Maintenance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "STOCKS"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1S As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button2 As Button
    Friend WithEvents Addbtn As Button
    Friend WithEvents Updtbtn As Button
    Friend WithEvents Dltbtn As Button
    Friend WithEvents Cancelbtn As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents Prodidbox As TextBox
    Friend WithEvents Txtbox2 As TextBox
    Friend WithEvents Txtbox3 As TextBox
    Friend WithEvents txtbox4 As TextBox
    Friend WithEvents txtbox5 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ComboBox1 As ComboBox
End Class
