﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Loginform
    Public LoginUser As String
    Public LoginPass As String
    Public UserType As String
    Public q As String





    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim adminLog As New AdminLog()
        adminLog.ShowDialog()

        Me.Hide()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim StaffLogin As New StaffLogin()
        StaffLogin.ShowDialog()
        Me.Hide()


    End Sub

    Private Sub Loginform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button2.Hide()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

    End Sub
End Class
