﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Catt
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        My.Forms.AddSupProd.ComboBox1.Items.Add(TextBox1.Text)
        My.Forms.Item1.ComboBox1.Items.Add(TextBox1.Text)
        ComboBox1.Items.Add(TextBox1.Text)
        MsgBox("Done", MsgBoxStyle.Information)


    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        My.Forms.AddSupProd.ComboBox1.Items.RemoveAt(ComboBox1.SelectedIndex)
        My.Forms.Item1.ComboBox1.Items.RemoveAt(ComboBox1.SelectedIndex)
        ComboBox1.Items.RemoveAt(ComboBox1.SelectedIndex)
        MsgBox("Removed", MsgBoxStyle.Information)
    End Sub




    Private Sub Categ_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Pota()

        DataGridView1.Columns(0).Width = 50

        DataGridView1.Columns(1).Width = 200
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        My.Forms.AddSupProd.ComboBox1.Items.Clear()
        My.Forms.Item1.ComboBox1.Items.Clear()
        ComboBox1.Items.Clear()

    End Sub



    Public Sub Pota()
        qr = "select * from SAMPLE"
        ds = Searchdata(qr)
        If (ds.Tables(0).Rows.Count > 0) Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            'MsgBox("Record not found..", MsgBoxStyle.Critical)
        End If
    End Sub



    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class